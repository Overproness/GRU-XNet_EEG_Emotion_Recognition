SCIENTIFIC EDITABLE SOURCES - AUTHOR-REVIEW DRAFT
Compile manuscript.tex and supplementary_methods.tex in this directory, using a normal current LaTeX/BibTeX environment or Tectonic. Use the matching separately supplied review PDF. The generated manuscript.bbl is included alongside references.bib. Tables are inline, not external inputs.
PLOS main artwork is a separate upload rather than embedded in the main PDF. MBEC includes separate display pages and a separate graphical abstract.
Ethics basis, author approval and contact completion remain pending. Do not treat the presence of these sources as readiness to submit. No administrative or fee-assistance documents are in this scientific ZIP.
