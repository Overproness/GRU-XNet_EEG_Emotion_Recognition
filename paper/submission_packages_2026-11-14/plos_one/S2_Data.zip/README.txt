Analysis-level evidence accompanying the exploratory FACED article.
Scientific result/prediction payloads are unchanged from the 16 October 2026 package. The earlier validation, ten-cell spectral comparison and one-cell neural diagnostic are different adaptive development evaluations, not independent replications.
Original FACED recordings/rating archives remain at doi:10.7303/syn50614194 under the original release access process. This archive contains coded-participant development predictions, summaries and manifests, not original BDF/header values, original rating archives, private checkpoints or reserved outcomes.
manifest.json binds the scientific payloads retained byte-for-byte. Only this packaging README was updated on 14 November 2026.
